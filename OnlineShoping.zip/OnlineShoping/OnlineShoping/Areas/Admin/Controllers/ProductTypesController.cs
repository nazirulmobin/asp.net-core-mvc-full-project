﻿using Microsoft.AspNetCore.Mvc;
using OnlineShoping.Data;
using OnlineShoping.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace OnlineShoping.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductTypesController : Controller
    {
        private ApplicationDbContext _db;
        public ProductTypesController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.ProductTypes.ToList());
        }

        //Create Get Action method
        public ActionResult Create()
        {
            return View();
        }

        //Create Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductTypes ProductTypes)
        {
            if (ModelState.IsValid)
            {
                _db.ProductTypes.Add(ProductTypes);
                await _db.SaveChangesAsync();
                TempData["Save"] = "Product Type has been saved";
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(ProductTypes);
        }

        //Get Edit Action method
        public ActionResult Edit(int? id)
        {
            if(id == null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypes.Find(id);
            if(productType == null)
            {
                return NotFound();
            }
            return View(productType);
        }

        //Create Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductTypes ProductTypes)
        {
            if (ModelState.IsValid)
            {
                _db.Update(ProductTypes);
                await _db.SaveChangesAsync();
                TempData["Update"] = "Product Type has been Updated";
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(ProductTypes);
        }

        //Get Details Action method
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypes.Find(id);
            if (productType == null)
            {
                return NotFound();
            }
            return View(productType);
        }

        //Details Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Details(ProductTypes ProductTypes)
        {
            
            return RedirectToAction(actionName: nameof(Index));
           
        }

        //Delete Action method
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var productType = _db.ProductTypes.Find(id);
            if (productType == null)
            {
                return NotFound();
            }
            return View(productType);
        }

        //Delete Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int? id, ProductTypes ProductTypes)
        {
            if (id ==null)
            {
                return NotFound();
            }
            if(id != ProductTypes.Id)
            {
                return NotFound();
            }
            var ProductType = _db.ProductTypes.Find(id);
            if(ProductType == null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _db.Remove(ProductType);
                await _db.SaveChangesAsync();
                TempData["Delete"] = "Product Type has been Deleted";
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(ProductTypes);
        }


    }
}
