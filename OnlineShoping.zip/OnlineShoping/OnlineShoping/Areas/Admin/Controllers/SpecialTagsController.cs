﻿using Microsoft.AspNetCore.Mvc;
using OnlineShoping.Data;
using OnlineShoping.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineShoping.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class SpecialTagsController : Controller
    {
        private ApplicationDbContext _db;
        
        public SpecialTagsController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            return View(_db.SpecialTags.ToList());
            // return View();
        }

        //Create Get Action method
        public ActionResult Create()
        {
            return View();
        }

        //Create Post Action Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SpecialTag SpecialTag)
        {
            if (ModelState.IsValid)
            {
                _db.SpecialTags.Add(SpecialTag);
                await _db.SaveChangesAsync();
                TempData["Save"] = "Special Tag has been saved";
                return RedirectToAction(actionName: nameof(Index));
            }
            return View(SpecialTag);
        }
    }
}
